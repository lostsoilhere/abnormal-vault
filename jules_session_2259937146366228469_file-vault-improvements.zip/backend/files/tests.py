from django.test import TestCase
from django.contrib.auth import get_user_model
from rest_framework.test import APIClient
from rest_framework.authtoken.models import Token
from .models import File
import os

User = get_user_model()

class FileViewSetTestCase(TestCase):
    def setUp(self):
        self.user = User.objects.create_user('testuser', password='testpassword')
        self.token = Token.objects.create(user=self.user)
        self.client = APIClient()
        self.client.credentials(HTTP_AUTHORIZATION='Token ' + self.token.key)

    def test_file_upload(self):
        file_path = 'test_file.txt'
        with open(file_path, 'w') as f:
            f.write('test content')

        with open(file_path, 'rb') as f:
            response = self.client.post('/api/files/', {'file': f}, format='multipart')
        
        self.assertEqual(response.status_code, 201)
        self.assertEqual(File.objects.count(), 1)
        self.assertEqual(File.objects.first().original_filename, 'test_file.txt')

        os.remove(file_path)

    def test_file_deduplication(self):
        file_path = 'test_file.txt'
        with open(file_path, 'w') as f:
            f.write('test content')

        with open(file_path, 'rb') as f:
            response1 = self.client.post('/api/files/', {'file': f}, format='multipart')
        
        self.assertEqual(response1.status_code, 201)
        self.assertEqual(File.objects.count(), 1)
        
        with open(file_path, 'rb') as f:
            response2 = self.client.post('/api/files/', {'file': f}, format='multipart')
            
        self.assertEqual(response2.status_code, 200)
        self.assertEqual(File.objects.count(), 1)

        os.remove(file_path)

    def test_search_and_filtering(self):
        file_path1 = 'test1.txt'
        file_path2 = 'test2.pdf'
        with open(file_path1, 'w') as f:
            f.write('test content 1')
        with open(file_path2, 'w') as f:
            f.write('test content 2')

        with open(file_path1, 'rb') as f:
            self.client.post('/api/files/', {'file': f}, format='multipart')
        with open(file_path2, 'rb') as f:
            self.client.post('/api/files/', {'file': f}, format='multipart')

        # Test filtering by file_type
        response = self.client.get('/api/files/?file_type=text/plain')
        self.assertEqual(response.status_code, 200)
        self.assertEqual(len(response.data), 1)
        self.assertEqual(response.data[0]['original_filename'], 'test1.txt')

        # Test searching by original_filename
        response = self.client.get('/api/files/?search=test2')
        self.assertEqual(response.status_code, 200)
        self.assertEqual(len(response.data), 1)
        self.assertEqual(response.data[0]['original_filename'], 'test2.pdf')

        os.remove(file_path1)
        os.remove(file_path2)

    def test_storage_limit(self):
        with self.settings(STORAGE_LIMIT_BYTES=10):
            file_path = 'test_file.txt'
            with open(file_path, 'w') as f:
                f.write('test content that is longer than 10 bytes')

            with open(file_path, 'rb') as f:
                response = self.client.post('/api/files/', {'file': f}, format='multipart')
            
            self.assertEqual(response.status_code, 400)
            self.assertEqual(response.data['error'], 'Storage limit exceeded')
            self.assertEqual(File.objects.count(), 0)

            os.remove(file_path)
