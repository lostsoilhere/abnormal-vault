import hashlib
from django.shortcuts import render
from rest_framework import viewsets, status
from rest_framework.response import Response
from rest_framework.filters import SearchFilter, OrderingFilter
from django_filters.rest_framework import DjangoFilterBackend
from .models import File
from .serializers import FileSerializer

def calculate_checksum(file_obj):
    sha256 = hashlib.sha256()
    for chunk in file_obj.chunks():
        sha256.update(chunk)
    return sha256.hexdigest()

class FileViewSet(viewsets.ModelViewSet):
    queryset = File.objects.all()
    serializer_class = FileSerializer
    throttle_scope = 'uploads'
    filter_backends = [DjangoFilterBackend, SearchFilter, OrderingFilter]
    filterset_fields = ['file_type']
    search_fields = ['original_filename']
    ordering_fields = ['uploaded_at', 'original_filename', 'size']

    def get_queryset(self):
        return self.queryset.filter(user=self.request.user)

    def create(self, request, *args, **kwargs):
        file_obj = request.FILES.get('file')
        
        if not self.check_storage_limit(request.user, file_obj.size):
            return Response({'error': 'Storage limit exceeded'}, status=status.HTTP_400_BAD_REQUEST)
            
        checksum = calculate_checksum(file_obj)

        # Check if user already has this file
        user_file = self.get_queryset().filter(checksum=checksum).first()
        if user_file:
            serializer = self.get_serializer(user_file)
            return Response(serializer.data, status=status.HTTP_200_OK)

        # Check if file exists globally
        existing_file = File.objects.filter(checksum=checksum).first()
        if existing_file:
            # If the file exists, create a new File record for the current user that points to the existing file
            file_record = File.objects.create(
                user=request.user,
                file=existing_file.file,
                checksum=checksum,
                original_filename=file_obj.name,
                file_type=file_obj.content_type,
                size=file_obj.size,
            )
            serializer = self.get_serializer(file_record)
            headers = self.get_success_headers(serializer.data)
            return Response(serializer.data, status=status.HTTP_201_CREATED, headers=headers)

        serializer = self.get_serializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        self.perform_create(serializer)
        headers = self.get_success_headers(serializer.data)
        return Response(serializer.data, status=status.HTTP_201_CREATED, headers=headers)

    def perform_create(self, serializer):
        file_obj = self.request.FILES.get('file')
        checksum = calculate_checksum(file_obj)
        serializer.save(user=self.request.user, checksum=checksum,
                        original_filename=file_obj.name,
                        file_type=file_obj.content_type,
                        size=file_obj.size)

    def check_storage_limit(self, user, new_file_size):
        from django.conf import settings
        from django.db import models
        
        current_storage = user.files.aggregate(total_size=models.Sum('size'))['total_size'] or 0
        return current_storage + new_file_size <= settings.STORAGE_LIMIT_BYTES
